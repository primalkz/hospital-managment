<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CarePoint - Appointment Page</title>
  {{-- app scripts --}}
  <script src="{{ asset('js/app.js') }}" defer></script>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
  <!-- Swiper CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
  <!-- Custom CSS -->
  <link href="{{ asset('css/app.css') }}" rel="stylesheet">
  <link href="{{ asset('css/dashboard.css') }}" rel="stylesheet">
</head>

<body>
  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <img src="https://placehold.co/80x80?text=CarePoint" alt="CarePoint Logo">
      <span class="brand-text">CarePoint</span>
    </div>
    <div class="sidebar-menu">
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-grid-1x2-fill"></i></span>
          <span class="sidebar-text">Dashboard</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-people-fill"></i></span>
          <span class="sidebar-text">Patients</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-clipboard2-pulse-fill"></i></span>
          <span class="sidebar-text">Doctors</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link active">
          <span class="sidebar-icon"><i class="bi bi-calendar-check-fill"></i></span>
          <span class="sidebar-text">Appointment</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-door-open-fill"></i></span>
          <span class="sidebar-text">Bedroom</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-file-earmark-medical-fill"></i></span>
          <span class="sidebar-text">Lab Reports</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-cash-stack"></i></span>
          <span class="sidebar-text">Transaction</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-person-plus-fill"></i></span>
          <span class="sidebar-text">Add Admin</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-gear-fill"></i></span>
          <span class="sidebar-text">Settings</span>
        </a>
      </div>
      <div class="sidebar-item mt-auto">
        <a href="index.html" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-box-arrow-left"></i></span>
          <span class="sidebar-text">Log out</span>
        </a>
      </div>
    </div>
  </div>

  <!-- Mobile Overlay -->
  <div class="mobile-overlay" id="mobileOverlay"></div>

  <!-- Header -->
  <header class="header" id="header">
    <button class="toggle-sidebar" id="toggleSidebar">
      <i class="bi bi-list"></i>
    </button>
    <form class="search-form-dash">
      <i class="bi bi-search search-icon"></i>
      <input type="search" class="form-control" placeholder="Search">
    </form>
    <div class="header-right">
      <div class="notification-bell">
        <i class="bi bi-bell"></i>
        <span class="notification-badge">3</span>
      </div>
      <div class="language-selector">
        <img src="https://placehold.co/100x100?text=EN" alt="English">
        <span>English</span>
        <i class="bi bi-chevron-down ms-1"></i>
      </div>
      <div class="user-profile">
        <img src="https://placehold.co/100x100?text=User" alt="User" class="user-avatar">
        <div class="user-info d-none d-md-block">
          <div class="user-name">Shanto</div>
          <div class="user-role">Admin</div>
        </div>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main class="main-content" id="mainContent">
    <div class="container-fluid py-4 appointment-disable-transitions">
      <!-- Page Title with stats -->
      <div class="row mb-0">
        <div class="col-12">
          {{-- <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
              <h4 class="mb-0">Appointments Management</h4>
              <div class="d-flex gap-3 mt-3 mt-md-0">
                <div class="d-flex flex-column justify-content-center align-items-center rounded-3 appointment-stat-card bg-primary text-white px-2 py-1">
                  <i class="bi bi-calendar-check"></i>
                  <div>
                    <h6>24 Today's Appointments</h6>
                  </div>
                </div>
                <div class="d-flex flex-column justify-content-center align-items-center rounded-3 appointment-stat-card bg-success text-white px-2 py-1">
                  <i class="bi bi-check-circle"></i>
                  <div>
                      <h6>18 Completed</h6>
                  </div>
                </div>
                <div class="d-flex flex-column justify-content-center align-items-center rounded-3 appointment-stat-card bg-warning text-white px-2 py-1">
                  <i class="bi bi-clock"></i>
                  <div>
                    <h6>6 Pending</h6>
                  </div>
                </div>
              </div>
            </div>
          </div> --}}
        </div>
      </div>

      <!-- Main Content Area -->
      <div class="row g-4">
        <!-- Appointments List -->
        <div class="col-lg-6">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Appointment List</h5>
              <div class="appointment-filter d-flex align-items-center">
                <div class="dropdown me-1">
                  <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-funnel me-1"></i> Filter
                  </button>
                  <ul class="dropdown-menu" aria-labelledby="filterDropdown">
                    <li><a class="dropdown-item" href="#">All Appointments</a></li>
                    <li><a class="dropdown-item" href="#">Today</a></li>
                    <li><a class="dropdown-item" href="#">This Week</a></li>
                    <li><a class="dropdown-item" href="#">This Month</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="#">Completed</a></li>
                    <li><a class="dropdown-item" href="#">Pending</a></li>
                    <li><a class="dropdown-item" href="#">Cancelled</a></li>
                  </ul>
                </div>
                {{-- <div class="position-relative search-mini">
                  <input type="text" class="form-control form-control-sm" placeholder="Search appointment">
                  <i class="bi bi-search search-mini-icon"></i>
                </div> --}}
                <form class="search-form">
                  {{-- <i class="bi bi-search search-icon"></i> --}}
                  <input type="search" class="form-control" placeholder="Search">
                </form>
              </div>
            </div>

            <ul class="nav nav-tabs mb-4" id="appointmentTabs" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link active" id="upcoming-tab" data-bs-toggle="tab" data-bs-target="#upcoming" type="button" role="tab" aria-controls="upcoming" aria-selected="true">Upcoming</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="past-tab" data-bs-toggle="tab" data-bs-target="#past" type="button" role="tab" aria-controls="past" aria-selected="false">Past</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="cancelled-tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab" aria-controls="cancelled" aria-selected="false">Cancelled</button>
              </li>
            </ul>

            <div class="tab-content" id="appointmentTabsContent">
              <div class="tab-pane fade show active" id="upcoming" role="tabpanel" aria-labelledby="upcoming-tab">
                <!-- Appointment Card -->
                <div class="appointment-card">
                  <div class="appointment-card-header">
                    <div class="appointment-date d-flex gap-1">
                      <div class="date-box d-flex gap-1">
                        <div class="date-month">May</div>
                        <div class="date-day">14</div>
                      </div>
                      <div class="date-time">09:30 AM</div>
                    </div>
                    <div class="appointment-status pending">
                      <i class="bi bi-clock"></i> Pending
                    </div>
                  </div>
                  <div class="appointment-card-body">
                    <div class="doctor-patient-info d-flex gap-2 flex-wrap mb-3">  
                      <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="appointment-avatar rounded-circle border">
                      <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                        <h6 class="my-1 mt-2 fw-light text-primary">Doctor</h6>
                        <h6 class="my-1 mt-2 fw-semibold">Dr. Emon Sheikh</h6>
                        <p class="appointment-specialty mb-0">Ophthalmologist</p>
                      </div>
                      
                      <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                        <h6 class="my-1 mt-2 fw-light text-secondary">Patient</h6>
                        <h6 class="my-1 mt-2 fw-semibold"> James Wilson</h6>
                        <div class="appointment-meta-item mb-0">+1 (555) 123-4567</div>
                      </div>

                    </div>
                  </div>
                  <div class="appointment-card-footer gap-1">
                    <button class="btn btn-sm btn-light my-1"><i class="bi bi-pencil"></i> Edit</button>
                    <button class="btn btn-sm btn-light my-1"><i class="bi bi-x-circle"></i> Cancel</button>
                    <button class="btn btn-sm btn-primary my-1"><i class="bi bi-check-circle"></i> Complete</button>
                  </div>
                </div>

                <!-- Appointment Card -->
                <div class="appointment-card">
                    <div class="appointment-card-header">
                      <div class="appointment-date d-flex gap-1">
                        <div class="date-box d-flex gap-1">
                          <div class="date-month">May</div>
                          <div class="date-day">14</div>
                        </div>
                        <div class="date-time">09:30 AM</div>
                      </div>
                      <div class="appointment-status pending">
                        <i class="bi bi-clock"></i> Pending
                      </div>
                    </div>
                    <div class="appointment-card-body">
                      <div class="doctor-patient-info d-flex gap-2 flex-wrap mb-3">  
                        <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="appointment-avatar rounded-circle border">
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-primary">Doctor</h6>
                          <h6 class="my-1 mt-2 fw-semibold">Dr. Emon Sheikh</h6>
                          <p class="appointment-specialty mb-0">Ophthalmologist</p>
                        </div>
                        
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-secondary">Patient</h6>
                          <h6 class="my-1 mt-2 fw-semibold"> James Wilson</h6>
                          <div class="appointment-meta-item mb-0">+1 (555) 123-4567</div>
                        </div>
  
                      </div>
                    </div>
                    <div class="appointment-card-footer gap-1">
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-pencil"></i> Edit</button>
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-x-circle"></i> Cancel</button>
                      <button class="btn btn-sm btn-primary my-1"><i class="bi bi-check-circle"></i> Complete</button>
                    </div>
                  </div>

                <!-- Appointment Card -->
                <div class="appointment-card">
                    <div class="appointment-card-header">
                      <div class="appointment-date d-flex gap-1">
                        <div class="date-box d-flex gap-1">
                          <div class="date-month">May</div>
                          <div class="date-day">14</div>
                        </div>
                        <div class="date-time">09:30 AM</div>
                      </div>
                      <div class="appointment-status pending">
                        <i class="bi bi-clock"></i> Pending
                      </div>
                    </div>
                    <div class="appointment-card-body">
                      <div class="doctor-patient-info d-flex gap-2 flex-wrap mb-3">  
                        <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="appointment-avatar rounded-circle border">
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-primary">Doctor</h6>
                          <h6 class="my-1 mt-2 fw-semibold">Dr. Emon Sheikh</h6>
                          <p class="appointment-specialty mb-0">Ophthalmologist</p>
                        </div>
                        
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-secondary">Patient</h6>
                          <h6 class="my-1 mt-2 fw-semibold"> James Wilson</h6>
                          <div class="appointment-meta-item mb-0">+1 (555) 123-4567</div>
                        </div>
  
                      </div>
                    </div>
                    <div class="appointment-card-footer gap-1">
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-pencil"></i> Edit</button>
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-x-circle"></i> Cancel</button>
                      <button class="btn btn-sm btn-primary my-1"><i class="bi bi-check-circle"></i> Complete</button>
                    </div>
                  </div>
              </div>

              <div class="tab-pane fade" id="past" role="tabpanel" aria-labelledby="past-tab">
                <!-- Appointment Card (Completed) -->
                <div class="appointment-card">
                    <div class="appointment-card-header">
                      <div class="appointment-date d-flex gap-1">
                        <div class="date-box d-flex gap-1">
                          <div class="date-month">May</div>
                          <div class="date-day">14</div>
                        </div>
                        <div class="date-time">09:30 AM</div>
                      </div>
                      <div class="appointment-status completed">
                        <i class="bi bi-check"></i> Completed
                      </div>
                    </div>
                    <div class="appointment-card-body">
                      <div class="doctor-patient-info d-flex gap-2 flex-wrap mb-3">  
                        <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="appointment-avatar rounded-circle border">
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-primary">Doctor</h6>
                          <h6 class="my-1 mt-2 fw-semibold">Dr. Emon Sheikh</h6>
                          <p class="appointment-specialty mb-0">Ophthalmologist</p>
                        </div>
                        
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-secondary">Patient</h6>
                          <h6 class="my-1 mt-2 fw-semibold"> James Wilson</h6>
                          <div class="appointment-meta-item mb-0">+1 (555) 123-4567</div>
                        </div>
  
                      </div>
                    </div>
                    <div class="appointment-card-footer gap-1">
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-pencil"></i> Edit</button>
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-x-circle"></i> Cancel</button>
                      <button class="btn btn-sm btn-primary my-1"><i class="bi bi-check-circle"></i> Complete</button>
                    </div>
                  </div>

                <!-- Appointment Card (Completed) -->
                <div class="appointment-card">
                    <div class="appointment-card-header">
                      <div class="appointment-date d-flex gap-1">
                        <div class="date-box d-flex gap-1">
                          <div class="date-month">May</div>
                          <div class="date-day">14</div>
                        </div>
                        <div class="date-time">09:30 AM</div>
                      </div>
                      <div class="appointment-status completed">
                        <i class="bi bi-check"></i> Completed
                      </div>
                    </div>
                    <div class="appointment-card-body">
                      <div class="doctor-patient-info d-flex gap-2 flex-wrap mb-3">  
                        <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="appointment-avatar rounded-circle border">
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-primary">Doctor</h6>
                          <h6 class="my-1 mt-2 fw-semibold">Dr. Emon Sheikh</h6>
                          <p class="appointment-specialty mb-0">Ophthalmologist</p>
                        </div>
                        
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-secondary">Patient</h6>
                          <h6 class="my-1 mt-2 fw-semibold"> James Wilson</h6>
                          <div class="appointment-meta-item mb-0">+1 (555) 123-4567</div>
                        </div>
  
                      </div>
                    </div>
                    <div class="appointment-card-footer gap-1">
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-pencil"></i> Edit</button>
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-x-circle"></i> Cancel</button>
                      <button class="btn btn-sm btn-primary my-1"><i class="bi bi-check-circle"></i> Complete</button>
                    </div>
                  </div>
              </div>

              <div class="tab-pane fade" id="cancelled" role="tabpanel" aria-labelledby="cancelled-tab">
                <!-- Appointment Card (Cancelled) -->
                <div class="appointment-card">
                    <div class="appointment-card-header">
                      <div class="appointment-date d-flex gap-1">
                        <div class="date-box d-flex gap-1">
                          <div class="date-month">May</div>
                          <div class="date-day">14</div>
                        </div>
                        <div class="date-time">09:30 AM</div>
                      </div>
                      <div class="appointment-status cancelled">
                        <i class="bi bi-x-circle"></i> Cancelled
                      </div>
                    </div>
                    <div class="appointment-card-body">
                      <div class="doctor-patient-info d-flex gap-2 flex-wrap mb-3">  
                        <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="appointment-avatar rounded-circle border">
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-primary">Doctor</h6>
                          <h6 class="my-1 mt-2 fw-semibold">Dr. Emon Sheikh</h6>
                          <p class="appointment-specialty mb-0">Ophthalmologist</p>
                        </div>
                        
                        <div class="px-2 py-2 my-2 border rounded-3 flex-wrap flex-fill">
                          <h6 class="my-1 mt-2 fw-light text-secondary">Patient</h6>
                          <h6 class="my-1 mt-2 fw-semibold"> James Wilson</h6>
                          <div class="appointment-meta-item mb-0">+1 (555) 123-4567</div>
                        </div>
  
                      </div>
                    </div>
                    <div class="appointment-card-footer gap-1">
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-pencil"></i> Edit</button>
                      <button class="btn btn-sm btn-light my-1"><i class="bi bi-x-circle"></i> Cancel</button>
                      <button class="btn btn-sm btn-primary my-1"><i class="bi bi-check-circle"></i> Complete</button>
                    </div>
                  </div>
              </div>
            </div>

            <div class="mt-4 text-center">
              <button class="btn btn-outline-primary">Load More</button>
            </div>
          </div>
        </div>

        <!-- Appointment Booking Form -->
        <div class="col-lg-6">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Book New Appointment</h5>
              <span class="badge bg-primary-light text-white">Step 1 of 3</span>
            </div>
            
            <form class="dr-appointment-form p-2">
              <!-- Step 1: Patient Information -->
              <div class="form-step active" id="step1">
                <h6 class="form-section-title">Patient Information</h6>
                
                <div class="mb-3">
                  <label for="patientType" class="form-label">Patient Type</label>
                  <div class="d-flex">
                    <div class="form-check me-4">
                      <input class="form-check-input" type="radio" name="patientType" id="existingPatient" checked>
                      <label class="form-check-label" for="existingPatient">
                        Existing Patient
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="patientType" id="newPatient">
                      <label class="form-check-label" for="newPatient">
                        New Patient
                      </label>
                    </div>
                  </div>
                </div>
                
                <div class="mb-3">
                  <label for="patientSearch" class="form-label">Search Patient</label>
                  <i class="bi bi-search search-input-icon"></i>
                  <div class="position-relative">
                    <input type="text" class="form-control" id="patientSearch" placeholder="Type patient name or ID">
                  </div>
                </div>
                
                <div class="selected-patient mb-4 border rounded-3 p-3">
                  <div class="d-flex align-items-center">
                    <img src="https://placehold.co/100x100?text=JW" alt="Patient" class="patient-avatar rounded-circle me-3">
                    <div>
                      <h6 class="mb-1">James Wilson</h6>
                      <p class="text-muted mb-0 small">ID: PT-20240514-001 | Age: 42</p>
                      <p class="text-muted mb-0 small">Phone: +1 (555) 123-4567</p>
                    </div>
                  </div>
                </div>
                
                <div class="mt-4 d-flex justify-content-end">
                  <button type="button" class="btn btn-primary" id="nextToStep2">Continue to Step 2</button>
                </div>
              </div>
              
              <!-- Step 2: Department & Doctor Selection -->
              <div class="form-step" id="step2">
                <h6 class="form-section-title">Department & Doctor</h6>
                
                <div class="mb-3">
                  <label for="departmentSelect" class="form-label">Select Department</label>
                  <select class="form-select" id="departmentSelect">
                    <option selected disabled>Choose department</option>
                    <option>Cardiology</option>
                    <option>Neurology</option>
                    <option>Ophthalmology</option>
                    <option>Dermatology</option>
                    <option>Psychiatry</option>
                    <option>Orthopedics</option>
                  </select>
                </div>
                
                <div class="mb-4">
                  <label class="form-label">Select Doctor</label>
                  
                  <div class="doctor-selection">
                    <div class="doctor-select-card">
                      <input type="radio" name="doctorSelect" id="doctor1" class="doctor-select-input">
                      <label for="doctor1" class="doctor-select-label">
                        <img src="https://placehold.co/100x100?text=Dr.E" alt="Doctor" class="doctor-select-avatar">
                        <div class="doctor-select-info">
                          <h6>Dr. Emon Sheikh</h6>
                          <p>Ophthalmologist</p>
                          <div class="doctor-rating">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-half"></i>
                            <span>4.8</span>
                          </div>
                        </div>
                      </label>
                    </div>
                    
                    <div class="doctor-select-card">
                      <input type="radio" name="doctorSelect" id="doctor2" class="doctor-select-input">
                      <label for="doctor2" class="doctor-select-label">
                        <img src="https://placehold.co/100x100?text=Dr.N" alt="Doctor" class="doctor-select-avatar">
                        <div class="doctor-select-info">
                          <h6>Dr. Nadia Rahman</h6>
                          <p>Ophthalmologist</p>
                          <div class="doctor-rating">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star"></i>
                            <span>4.1</span>
                          </div>
                        </div>
                      </label>
                    </div>
                    
                    <div class="doctor-select-card">
                      <input type="radio" name="doctorSelect" id="doctor3" class="doctor-select-input">
                      <label for="doctor3" class="doctor-select-label">
                        <img src="https://placehold.co/100x100?text=Dr.R" alt="Doctor" class="doctor-select-avatar">
                        <div class="doctor-select-info">
                          <h6>Dr. Rebecca Johnson</h6>
                          <p>Ophthalmologist</p>
                          <div class="doctor-rating">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <span>5.0</span>
                          </div>
                        </div>
                      </label>
                    </div>
                  </div>
                </div>
                
                <div class="mt-4 d-flex justify-content-between">
                  <button type="button" class="btn btn-outline-secondary" id="backToStep1">Back</button>
                  <button type="button" class="btn btn-primary" id="nextToStep3">Continue to Step 3</button>
                </div>
              </div>
              
              <!-- Step 3: Date & Time Selection -->
              <div class="form-step" id="step3">
                <h6 class="form-section-title">Appointment Date & Time</h6>
                
                <div class="mb-3">
                  <label class="form-label">Select Date</label>
                  <div class="date-picker">
                    <div class="date-selector">
                      <div class="date-nav">
                        <button type="button" class="btn btn-sm date-nav-btn">
                          <i class="bi bi-chevron-left"></i>
                        </button>
                        <span class="date-nav-title">May 14 - May 20, 2025</span>
                        <button type="button" class="btn btn-sm date-nav-btn">
                          <i class="bi bi-chevron-right"></i>
                        </button>
                      </div>
                      
                      <div class="date-grid">
                        <div class="date-item">
                          <div class="date-weekday">Tue</div>
                          <div class="date-day selected">14</div>
                        </div>
                        <div class="date-item">
                          <div class="date-item">
                          <div class="date-weekday">Tue</div>
                          <div class="date-day selected">14</div>
                        </div>
                        <div class="date-item">
                          <div class="date-weekday">Wed</div>
                          <div class="date-day">15</div>
                        </div>
                        <div class="date-item">
                          <div class="date-weekday">Thu</div>
                          <div class="date-day">16</div>
                        </div>
                        <div class="date-item">
                          <div class="date-weekday">Fri</div>
                          <div class="date-day">17</div>
                        </div>
                        <div class="date-item">
                          <div class="date-weekday">Sat</div>
                          <div class="date-day">18</div>
                        </div>
                        <div class="date-item">
                          <div class="date-weekday">Sun</div>
                          <div class="date-day">19</div>
                        </div>
                        <div class="date-item">
                          <div class="date-weekday">Mon</div>
                          <div class="date-day">20</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="mb-4">
                  <label class="form-label">Select Time Slot</label>
                  <div class="time-slot-container">
                    <div class="time-slot-section">
                      <h6 class="time-slot-title">Morning</h6>
                      <div class="time-slot-grid">
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time1" class="time-slot-input">
                          <label for="time1" class="time-slot-label">09:00 AM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time2" class="time-slot-input">
                          <label for="time2" class="time-slot-label">09:30 AM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time3" class="time-slot-input">
                          <label for="time3" class="time-slot-label">10:00 AM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time4" class="time-slot-input" disabled>
                          <label for="time4" class="time-slot-label">10:30 AM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time5" class="time-slot-input">
                          <label for="time5" class="time-slot-label">11:00 AM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time6" class="time-slot-input">
                          <label for="time6" class="time-slot-label">11:30 AM</label>
                        </div>
                      </div>
                    </div>
                    
                    <div class="time-slot-section">
                      <h6 class="time-slot-title">Afternoon</h6>
                      <div class="time-slot-grid">
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time7" class="time-slot-input" disabled>
                          <label for="time7" class="time-slot-label">01:00 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time8" class="time-slot-input" disabled>
                          <label for="time8" class="time-slot-label">01:30 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time9" class="time-slot-input">
                          <label for="time9" class="time-slot-label">02:00 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time10" class="time-slot-input">
                          <label for="time10" class="time-slot-label">02:30 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time11" class="time-slot-input">
                          <label for="time11" class="time-slot-label">03:00 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time12" class="time-slot-input">
                          <label for="time12" class="time-slot-label">03:30 PM</label>
                        </div>
                      </div>
                    </div>
                    
                    <div class="time-slot-section">
                      <h6 class="time-slot-title">Evening</h6>
                      <div class="time-slot-grid">
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time13" class="time-slot-input">
                          <label for="time13" class="time-slot-label">04:00 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time14" class="time-slot-input">
                          <label for="time14" class="time-slot-label">04:30 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time15" class="time-slot-input">
                          <label for="time15" class="time-slot-label">05:00 PM</label>
                        </div>
                        <div class="time-slot-item">
                          <input type="radio" name="timeSlot" id="time16" class="time-slot-input">
                          <label for="time16" class="time-slot-label">05:30 PM</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="mb-3">
                  <label for="appointmentReason" class="form-label">Reason for Appointment</label>
                  <select class="form-select" id="appointmentReason">
                    <option selected disabled>Select reason</option>
                    <option>Regular Check-up</option>
                    <option>Follow-up Visit</option>
                    <option>New Symptoms</option>
                    <option>Prescription Renewal</option>
                    <option>Test Results Review</option>
                    <option>Other</option>
                  </select>
                </div>
                
                <div class="mb-3">
                  <label for="appointmentNotes" class="form-label">Additional Notes</label>
                  <textarea class="form-control" id="appointmentNotes" rows="3" placeholder="Provide any details about your condition or specific needs"></textarea>
                </div>
                
                <div class="mt-4 d-flex justify-content-between">
                  <button type="button" class="btn btn-outline-secondary" id="backToStep2">Back</button>
                  <button type="submit" class="btn btn-success">
                    <i class="bi bi-calendar-check"></i> Book Appointment
                  </button>
                </div>
              </div>
            </form>
          </div>
          
          <!-- Doctor Schedule Card -->
          <div class="mt-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h5 class="mb-0">Doctor's Schedule</h5>
              <button class="btn btn-sm btn-light">
                <i class="bi bi-calendar3"></i> View Full Calendar
              </button>
            </div>
            
            <div class="schedule-timeline d-flex gap-2">
              <div class="schedule-day">
                <div class="schedule-date">
                  <span class="schedule-weekday">Today</span>
                  <span class="schedule-day-num">14</span>
                </div>
                <div class="schedule-appointments mt-2">
                  <div class="schedule-appointment-item border mb-2 p-2 py-1 rounded-3 bg-light">
                    <div class="schedule-time">09:30 AM</div>
                    <div class="schedule-info">
                      <h6>James Wilson</h6>
                      <p>Regular Check-up</p>
                    </div>
                  </div>
                  <div class="schedule-appointment-item border mb-2 p-2 py-1 rounded-3 bg-light">
                    <div class="schedule-time">11:00 AM</div>
                    <div class="schedule-info">
                      <h6>Sophia Chen</h6>
                      <p>Follow-up Visit</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="schedule-day">
                <div class="schedule-date">
                  <span class="schedule-weekday">Wed</span>
                  <span class="schedule-day-num">15</span>
                </div>
                <div class="schedule-appointments mt-2">
                  <div class="schedule-appointment-item border mb-2 p-2 py-1 rounded-3 bg-light">
                    <div class="schedule-time">10:00 AM</div>
                    <div class="schedule-info">
                      <h6>Robert Harris</h6>
                      <p>Prescription Renewal</p>
                    </div>
                  </div>
                  <div class="schedule-appointment-item border mb-2 p-2 py-1 rounded-3 bg-light">
                    <div class="schedule-time">02:15 PM</div>
                    <div class="schedule-info">
                      <h6>Michael Rodriguez</h6>
                      <p>New Symptoms</p>
                    </div>
                  </div>
                  <div class="schedule-appointment-item border mb-2 p-2 py-1 rounded-3 bg-light">
                    <div class="schedule-time">04:45 PM</div>
                    <div class="schedule-info">
                      <h6>Emily Parker</h6>
                      <p>Test Results Review</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Bootstrap & jQuery JS -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Swiper JS -->
  <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
  
  <script>
    // Sidebar toggle functionality
    const toggleSidebar = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const mobileOverlay = document.getElementById('mobileOverlay');
    const mainContent = document.getElementById('mainContent');
    const header = document.getElementById('header');
    
    toggleSidebar.addEventListener('click', function() {
      sidebar.classList.toggle('collapsed');
      mainContent.classList.toggle('expanded');
      header.classList.toggle('expanded');
      
      if (window.innerWidth < 992) {
        mobileOverlay.classList.toggle('active');
      }
    });
    
    mobileOverlay.addEventListener('click', function() {
      sidebar.classList.remove('collapsed');
      mobileOverlay.classList.remove('active');
    });
    
    // Form step navigation
    const nextToStep2 = document.getElementById('nextToStep2');
    const backToStep1 = document.getElementById('backToStep1');
    const nextToStep3 = document.getElementById('nextToStep3');
    const backToStep2 = document.getElementById('backToStep2');
    
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const step3 = document.getElementById('step3');
    
    nextToStep2.addEventListener('click', function() {
      step1.classList.remove('active');
      step2.classList.add('active');
    });
    
    backToStep1.addEventListener('click', function() {
      step2.classList.remove('active');
      step1.classList.add('active');
    });
    
    nextToStep3.addEventListener('click', function() {
      step2.classList.remove('active');
      step3.classList.add('active');
    });
    
    backToStep2.addEventListener('click', function() {
      step3.classList.remove('active');
      step2.classList.add('active');
    });
  </script>
</body>
</html>