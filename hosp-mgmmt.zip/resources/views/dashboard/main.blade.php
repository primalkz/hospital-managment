<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CarePoint - Medical Dashboard</title>
  {{-- app scripts --}}
  <script src="{{ asset('js/app.js') }}" defer></script>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
  <!-- Swiper CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
  <!-- Custom CSS -->
  <link href="{{ asset('css/app.css') }}" rel="stylesheet">
  <link href="{{ asset('css/dashboard.css') }}" rel="stylesheet">
</head>

<body>
  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <img src="https://placehold.co/80x80?text=CarePoint" alt="CarePoint Logo">
      <span class="brand-text">CarePoint</span>
    </div>
    <div class="sidebar-menu">
      <div class="sidebar-item">
        <a href="#" class="sidebar-link active">
          <span class="sidebar-icon"><i class="bi bi-grid-1x2-fill"></i></span>
          <span class="sidebar-text">Dashboard</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-people-fill"></i></span>
          <span class="sidebar-text">Patients</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-clipboard2-pulse-fill"></i></span>
          <span class="sidebar-text">Doctors</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="{{ route('dashboard.appointment') }}" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-calendar-check-fill"></i></span>
          <span class="sidebar-text">Appointment</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-door-open-fill"></i></span>
          <span class="sidebar-text">Bedroom</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-file-earmark-medical-fill"></i></span>
          <span class="sidebar-text">Lab Reports</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-cash-stack"></i></span>
          <span class="sidebar-text">Transaction</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-person-plus-fill"></i></span>
          <span class="sidebar-text">Add Admin</span>
        </a>
      </div>
      <div class="sidebar-item">
        <a href="#" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-gear-fill"></i></span>
          <span class="sidebar-text">Settings</span>
        </a>
      </div>
      <div class="sidebar-item mt-auto">
        <a href="index.html" class="sidebar-link">
          <span class="sidebar-icon"><i class="bi bi-box-arrow-left"></i></span>
          <span class="sidebar-text">Log out</span>
        </a>
      </div>
    </div>
  </div>

  <!-- Mobile Overlay -->
  <div class="mobile-overlay" id="mobileOverlay"></div>

  <!-- Header -->
  <header class="header" id="header">
    <button class="toggle-sidebar" id="toggleSidebar">
      <i class="bi bi-list"></i>
    </button>
    <form class="search-form-dash">
      <i class="bi bi-search search-icon"></i>
      <input type="search" class="form-control" placeholder="Search">
    </form>
    <div class="header-right">
      <div class="notification-bell">
        <i class="bi bi-bell"></i>
        <span class="notification-badge">3</span>
      </div>
      <div class="language-selector">
        <img src="https://placehold.co/100x100?text=EN" alt="English">
        <span>English</span>
        <i class="bi bi-chevron-down ms-1"></i>
      </div>
      <div class="user-profile">
        <img src="https://placehold.co/100x100?text=User" alt="User" class="user-avatar">
        <div class="user-info d-none d-md-block">
          <div class="user-name">Shanto</div>
          <div class="user-role">Admin</div>
        </div>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main class="main-content" id="mainContent">
    <div class="container-fluid py-4">
      <!-- Statistics Cards -->
      <div class="row g-4 mb-4">
        <div class="col-md-6 col-lg-3">
          <div class="dashboard-card stat-card">
            <div class="stat-card-header">
              <div class="stat-card-icon bg-primary-light text-white">
                <i class="bi bi-person-fill"></i>
              </div>
              <h6 class="stat-card-title">Total Doctors</h6>
            </div>
            <div class="stat-card-value">40</div>
            <div class="stat-card-trend trend-up">
              <i class="bi bi-graph-up-arrow trend-icon"></i>
              <span>3 Doctors joined this week</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="dashboard-card stat-card">
            <div class="stat-card-header">
              <div class="stat-card-icon bg-success text-white">
                <i class="bi bi-people-fill"></i>
              </div>
              <h6 class="stat-card-title">Total Patient</h6>
            </div>
            <div class="stat-card-value">14685</div>
            <div class="stat-card-trend trend-up">
              <i class="bi bi-graph-up-arrow trend-icon"></i>
              <span>1.3% Up from past week</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="dashboard-card stat-card">
            <div class="stat-card-header">
              <div class="stat-card-icon bg-warning text-white">
                <i class="bi bi-cash"></i>
              </div>
              <h6 class="stat-card-title">Total Transaction</h6>
            </div>
            <div class="stat-card-value">$89,0000</div>
            <div class="stat-card-trend trend-down">
              <i class="bi bi-graph-down-arrow trend-icon"></i>
              <span>4.3% Down from yesterday</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="dashboard-card stat-card">
            <div class="stat-card-header">
              <div class="stat-card-icon bg-danger text-white">
                <i class="bi bi-calendar-check"></i>
              </div>
              <h6 class="stat-card-title">Total Appointment</h6>
            </div>
            <div class="stat-card-value">1460</div>
            <div class="stat-card-trend trend-up">
              <i class="bi bi-graph-up-arrow trend-icon"></i>
              <span>1.8% Up from yesterday</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Second Row -->
      <div class="row g-4 mb-4">
        <!-- Appointment Section -->
        <div class="col-lg-8">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Appointment</h5>
              <a href="#" class="text-decoration-none text-primary">View all</a>
            </div>
            <div class="appointment-list">
              <div class="appointment-item">
                <img src="https://placehold.co/100x100?text=Dr.M" alt="Doctor" class="doctor-avatar">
                <div class="appointment-details">
                  <h6 class="doctor-name">Dr Mamun</h6>
                  <p class="doctor-specialty">Psychiatrist</p>
                </div>
                <div class="appointment-time">
                  <div class="time-label">Today</div>
                  <div class="time-value">09:40</div>
                </div>
              </div>
              <div class="appointment-item">
                <img src="https://placehold.co/100x100?text=Dr.R" alt="Doctor" class="doctor-avatar">
                <div class="appointment-details">
                  <h6 class="doctor-name">Dr Rebecca</h6>
                  <p class="doctor-specialty">Internist</p>
                </div>
                <div class="appointment-time">
                  <div class="time-label">Today</div>
                  <div class="time-value">10:00</div>
                </div>
              </div>
              <div class="appointment-item">
                <img src="https://placehold.co/100x100?text=Dr.E" alt="Doctor" class="doctor-avatar">
                <div class="appointment-details">
                  <h6 class="doctor-name">Dr Emon</h6>
                  <p class="doctor-specialty">Ophthalmologist</p>
                </div>
                <div class="appointment-time">
                  <div class="time-label">Today</div>
                  <div class="time-value">10:30</div>
                </div>
              </div>
              <div class="appointment-item">
                <img src="https://placehold.co/100x100?text=Dr.N" alt="Doctor" class="doctor-avatar">
                <div class="appointment-details">
                  <h6 class="doctor-name">Dr Nadia</h6>
                  <p class="doctor-specialty">Ophthalmologist</p>
                </div>
                <div class="appointment-time">
                  <div class="time-label">Today</div>
                  <div class="time-value">10:30</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Room Availability -->
        <div class="col-lg-4">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Room Availability</h5>
              <a href="#" class="text-decoration-none text-primary">Details</a>
            </div>
            <div class="room-list">
              <div class="room-item">
                <div class="room-type">
                  <div class="room-icon bg-primary">
                    <i class="bi bi-hospital"></i>
                  </div>
                  <span>General Ward</span>
                </div>
                <div class="room-count">56</div>
              </div>
              <div class="room-item">
                <div class="room-type">
                  <div class="room-icon bg-info">
                    <i class="bi bi-door-closed"></i>
                  </div>
                  <span>Private Room</span>
                </div>
                <div class="room-count">45</div>
              </div>
              <div class="room-item">
                <div class="room-type">
                  <div class="room-icon bg-success">
                    <i class="bi bi-door-open"></i>
                  </div>
                  <span>Semi-private Room</span>
                </div>
                <div class="room-count">32</div>
              </div>
              <div class="room-item">
                <div class="room-type">
                  <div class="room-icon bg-danger">
                    <i class="bi bi-heart-pulse"></i>
                  </div>
                  <span>Emergency Room</span>
                </div>
                <div class="room-count">12</div>
              </div>
              <div class="room-item">
                <div class="room-type">
                  <div class="room-icon bg-success">
                    <i class="bi bi-bandaid"></i>
                  </div>
                  <span>ICU</span>
                </div>
                <div class="room-count">10</div>
              </div>
              <div class="room-item">
                <div class="room-type">
                  <div class="room-icon bg-warning">
                    <i class="bi bi-scissors"></i>
                  </div>
                  <span>Operation Theatre</span>
                </div>
                <div class="room-count">4</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Third Row -->
      <div class="row g-4 mb-4">
        <!-- Most Visited Dept -->
        <div class="col-lg-4">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Most Visited Dept.</h5>
              <a href="#" class="text-decoration-none text-primary">Details</a>
            </div>
            <div class="text-center mb-4">
              <canvas id="deptChart" width="250" height="250"></canvas>
            </div>
            <div class="d-flex justify-content-around">
              <div class="text-center">
                <div class="d-flex align-items-center justify-content-center mb-2">
                  <div class="me-2" style="width: 12px; height: 12px; border-radius: 50%; background-color: #4CAF50;"></div>
                  <span>60%</span>
                </div>
                <p class="mb-0 small">Cardiology</p>
              </div>
              <div class="text-center">
                <div class="d-flex align-items-center justify-content-center mb-2">
                  <div class="me-2" style="width: 12px; height: 12px; border-radius: 50%; background-color: #FFC107;"></div>
                  <span>30%</span>
                </div>
                <p class="mb-0 small">Neurology</p>
              </div>
              <div class="text-center">
                <div class="d-flex align-items-center justify-content-center mb-2">
                  <div class="me-2" style="width: 12px; height: 12px; border-radius: 50%; background-color: #2196F3;"></div>
                  <span>10%</span>
                </div>
                <p class="mb-0 small">Dermatology</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Reported Cases -->
        <div class="col-lg-4">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Reported Cases</h5>
              <div class="dropdown">
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="casesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                  Neurology
                </button>
                <ul class="dropdown-menu" aria-labelledby="casesDropdown">
                  <li><a class="dropdown-item" href="#">Cardiology</a></li>
                  <li><a class="dropdown-item" href="#">Neurology</a></li>
                  <li><a class="dropdown-item" href="#">Orthopedics</a></li>
                </ul>
              </div>
            </div>
            <div>
              <canvas id="casesChart" height="250"></canvas>
            </div>
            <div class="d-flex justify-content-center mt-3">
              <div class="d-flex align-items-center me-4">
                <div style="width: 12px; height: 12px; background-color: #4285f4; border-radius: 50%; margin-right: 8px;"></div>
                <span>Positive</span>
              </div>
              <div class="d-flex align-items-center">
                <div style="width: 12px; height: 12px; background-color: #fbbc05; border-radius: 50%; margin-right: 8px;"></div>
                <span>Negative</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Reports -->
        <div class="col-lg-4">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Reports</h5>
              <a href="#" class="text-decoration-none text-primary">View all</a>
            </div>
            <div class="reports-list">
              <div class="report-item">
                <div class="report-icon">
                  <i class="bi bi-exclamation-triangle"></i>
                </div>
                <div class="report-details">
                  <h6 class="report-title">A shower broken in room number 135...</h6>
                  <p class="report-time">1 minute ago</p>
                </div>
                <a href="#" class="report-action">
                  View Report <i class="bi bi-arrow-right"></i>
                </a>
              </div>
              <div class="report-item">
                <div class="report-icon">
                  <i class="bi bi-exclamation-triangle"></i>
                </div>
                <div class="report-details">
                  <h6 class="report-title">A shower broken in room number 135...</h6>
                  <p class="report-time">1 minute ago</p>
                </div>
                <a href="#" class="report-action">
                  View Report <i class="bi bi-arrow-right"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Fourth Row -->
      <div class="row g-4">
        <!-- Doctors List -->
        <div class="col-lg-12">
          <div class="dashboard-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h5 class="mb-0">Doctors List</h5>
              <a href="#" class="text-decoration-none text-primary">View all</a>
            </div>
            <div class="doctors-list">
              <div class="doctor-list-item">
                <div class="doctor-info">
                  <img src="https://placehold.co/100x100?text=Dr.M" alt="Doctor" class="doctor-list-avatar">
                  <div class="doctor-list-details">
                    <h6>Dr Mamun</h6>
                    <p>Psychiatrist</p>
                  </div>
                </div>
                <div class="doctor-actions">
                  <i class="bi bi-three-dots-vertical"></i>
                </div>
              </div>
              <div class="doctor-list-item">
                <div class="doctor-info">
                  <img src="https://placehold.co/100x100?text=Dr.R" alt="Doctor" class="doctor-list-avatar">
                  <div class="doctor-list-details">
                    <h6>Dr Rebecca</h6>
                    <p>Psychiatrist</p>
                  </div>
                </div>
                <div class="doctor-actions">
                  <i class="bi bi-three-dots-vertical"></i>
                </div>
              </div>
              <div class="doctor-list-item">
                <div class="doctor-info">
                  <img src="https://placehold.co/100x100?text=Dr.E" alt="Doctor" class="doctor-list-avatar">
                  <div class="doctor-list-details">
                    <h6>Dr Emon</h6>
                    <p>Psychiatrist</p>
                  </div>
                </div>
                <div class="doctor-actions">
                  <i class="bi bi-three-dots-vertical"></i>
                </div>
              </div>
              <div class="doctor-list-item">
                <div class="doctor-info">
                  <img src="https://placehold.co/100x100?text=Dr.N" alt="Doctor" class="doctor-list-avatar">
                  <div class="doctor-list-details">
                    <h6>Dr Nadia</h6>
                    <p>Psychiatrist</p>
                  </div>
                </div>
                <div class="doctor-actions">
                  <i class="bi bi-three-dots-vertical"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Bootstrap 5 JS Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
  
  <!-- Custom JS -->
  <script>
    // Toggle Sidebar
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    const header = document.getElementById('header');
    const toggleSidebar = document.getElementById('toggleSidebar');
    const mobileOverlay = document.getElementById('mobileOverlay');

    toggleSidebar.addEventListener('click', function() {
      sidebar.classList.remove("mobile-open");
      sidebar.classList.toggle('collapsed');
      mainContent.classList.toggle('expanded');
      header.classList.toggle('expanded');
      
      // For mobile
      if (window.innerWidth < 992) {    
        sidebar.classList.remove('collapsed');
        sidebar.classList.toggle('mobile-open');
        mobileOverlay.classList.toggle('active');
        mainContent.classList.toggle('expanded');
        header.classList.toggle('expanded');
      }
    });
    
    mobileOverlay.addEventListener('click', function() {
      sidebar.classList.remove('mobile-open');
      mobileOverlay.classList.remove('active');
    });
    
    // Department Chart
    const deptCtx = document.getElementById('deptChart').getContext('2d');
    const deptChart = new Chart(deptCtx, {
      type: 'doughnut',
      data: {
        labels: ['Cardiology', 'Neurology', 'Dermatology'],
        datasets: [{
          data: [60, 30, 10],
          backgroundColor: [
            '#4CAF50',
            '#FFC107',
            '#2196F3'
          ],
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });
    
    // Cases Chart
    const casesCtx = document.getElementById('casesChart').getContext('2d');
    const casesChart = new Chart(casesCtx, {
      type: 'line',
      data: {
        labels: ['', '', '', '', '', ''],
        datasets: [
          {
            label: 'Positive',
            data: [10, 15, 20, 25, 30, 35],
            borderColor: '#4285f4',
            backgroundColor: 'rgba(66, 133, 244, 0.1)',
            tension: 0.4,
            fill: true
          },
          {
            label: 'Negative',
            data: [5, 10, 15, 20, 25, 30],
            borderColor: '#fbbc05',
            backgroundColor: 'rgba(251, 188, 5, 0.1)',
            tension: 0.4,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            grid: {
              display: true,
              drawBorder: false
            },
            ticks: {
              display: false
            }
          },
          x: {
            grid: {
              display: false,
              drawBorder: false
            },
            ticks: {
              display: false
            }
          }
        },
        plugins: {
          legend: {
            display: false
          }
        },
        elements: {
          point: {
            radius: 0
          }
        }
      }
    });
  </script>
</body>
</html>