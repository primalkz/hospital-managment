<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AppointmentController extends Controller
{
    public function index()
    {
        $appointments = Appointment::with(['doctor', 'patient'])
            ->when(Auth::user()->type === 'patient', function ($query) {
                return $query->where('patient_id', Auth::id());
            })
            ->when(Auth::user()->type === 'doctor', function ($query) {
                return $query->where('doctor_id', Auth::id());
            })
            ->orderBy('appointment_date', 'asc')
            ->orderBy('appointment_time', 'asc')
            ->get();

        $doctors = User::where('type', 'doctor')->get();
        return view('dashboard.appointment', compact('appointments', 'doctors'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'patient_id' => 'required|exists:users,id',
            'doctor_id' => 'required|exists:users,id',
            'appointment_date' => 'required|date|after_or_equal:today',
            'appointment_time' => 'required',
            'reason' => 'required|string',
            'notes' => 'nullable|string',
            'department' => 'required|string',
        ]);

        $appointment = Appointment::create($validated);

        return redirect()->route('dashboard.appointment')
            ->with('success', 'Appointment booked successfully!');
    }

    public function update(Request $request, Appointment $appointment)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,confirmed,completed,cancelled',
        ]);

        $appointment->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Appointment status updated successfully!',
            'appointment' => $appointment
        ]);
    }

    public function checkAvailability(Request $request)
    {
        $validated = $request->validate([
            'doctor_id' => 'required|exists:users,id',
            'date' => 'required|date|after_or_equal:today',
        ]);

        $bookedSlots = Appointment::where('doctor_id', $validated['doctor_id'])
            ->where('appointment_date', $validated['date'])
            ->pluck('appointment_time')
            ->toArray();

        // Generate all available time slots
        $timeSlots = $this->generateTimeSlots();
        
        // Mark booked slots as unavailable
        foreach ($timeSlots as &$slot) {
            $slot['available'] = !in_array($slot['time'], $bookedSlots);
        }

        return response()->json([
            'success' => true,
            'timeSlots' => $timeSlots
        ]);
    }

    private function generateTimeSlots()
    {
        $slots = [];
        $start = strtotime('09:00');
        $end = strtotime('17:30');
        $interval = 30 * 60; // 30 minutes

        for ($time = $start; $time <= $end; $time += $interval) {
            $slots[] = [
                'time' => date('H:i', $time),
                'formatted' => date('h:i A', $time),
                'available' => true
            ];
        }

        return $slots;
    }
}
