<?php $__env->startSection('title', 'Appointment'); ?>
<?php $__env->startSection('content'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- Main Content -->
<link href="<?php echo e(asset('css/appointment.css')); ?>" rel="stylesheet">
<main class="main-content" id="mainContent">
    <div class="container-fluid py-4">
      <!-- Page Title with stats -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="card border-0 shadow-sm rounded-lg">
            <div class="card-body p-4">
              <div class="d-flex justify-content-between align-items-center flex-wrap">
                <h4 class="mb-0 fw-bold text-dark">Appointments Management</h4>
                <div class="d-flex gap-3 mt-3 mt-md-0">
                  <div class="stat-card bg-primary bg-opacity-10 rounded-lg p-3">
                    <div class="d-flex align-items-center mb-2">
                      <div class="stat-icon bg-primary rounded-circle p-2 me-2">
                        <i class="bi bi-calendar-check text-white"></i>
                      </div>
                      <h6 class="stat-title mb-0 text-primary">Today's Appointments</h6>
                    </div>
                    <div class="stat-value fw-bold fs-4">24</div>
                  </div>
                  <div class="stat-card bg-success bg-opacity-10 rounded-lg p-3">
                    <div class="d-flex align-items-center mb-2">
                      <div class="stat-icon bg-success rounded-circle p-2 me-2">
                        <i class="bi bi-check-circle text-white"></i>
                      </div>
                      <h6 class="stat-title mb-0 text-success">Completed</h6>
                    </div>
                    <div class="stat-value fw-bold fs-4">18</div>
                  </div>
                  <div class="stat-card bg-warning bg-opacity-10 rounded-lg p-3">
                    <div class="d-flex align-items-center mb-2">
                      <div class="stat-icon bg-warning rounded-circle p-2 me-2">
                        <i class="bi bi-clock text-white"></i>
                      </div>
                      <h6 class="stat-title mb-0 text-warning">Pending</h6>
                    </div>
                    <div class="stat-value fw-bold fs-4">6</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Content Area -->
      <div class="row g-4">
        <!-- Appointments List -->
        <div class="col-lg-6">
          <div class="card border-0 shadow-sm rounded-lg">
            <div class="card-body p-4">
              <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 fw-bold">Appointment List</h5>
                <div class="appointment-filter d-flex align-items-center gap-2">
                  <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="bi bi-funnel me-1"></i> Filter
                    </button>
                    <ul class="dropdown-menu shadow border-0" aria-labelledby="filterDropdown">
                      <li><a class="dropdown-item" href="#">All Appointments</a></li>
                      <li><a class="dropdown-item" href="#">Today</a></li>
                      <li><a class="dropdown-item" href="#">This Week</a></li>
                      <li><a class="dropdown-item" href="#">This Month</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="#">Completed</a></li>
                      <li><a class="dropdown-item" href="#">Pending</a></li>
                      <li><a class="dropdown-item" href="#">Cancelled</a></li>
                    </ul>
                  </div>
                  <form class="search-form position-relative">
                    <input type="search" class="form-control form-control-sm ps-4" placeholder="Search">
                    <i class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-2 text-muted"></i>
                  </form>
                </div>
              </div>

              <ul class="nav nav-pills mb-4" id="appointmentTabs" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active px-4" id="upcoming-tab" data-bs-toggle="tab" data-bs-target="#upcoming" type="button" role="tab" aria-controls="upcoming" aria-selected="true">Upcoming</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link px-4" id="past-tab" data-bs-toggle="tab" data-bs-target="#past" type="button" role="tab" aria-controls="past" aria-selected="false">Past</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link px-4" id="cancelled-tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab" aria-controls="cancelled" aria-selected="false">Cancelled</button>
                </li>
              </ul>

              <div class="tab-content" id="appointmentTabsContent">
                <div class="tab-pane fade show active" id="upcoming" role="tabpanel" aria-labelledby="upcoming-tab">
                  <!-- Appointment Card -->
                  <div class="card border-0 shadow-sm rounded-lg mb-3">
                    <div class="card-body p-3">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                          <div class="date-box text-center me-3 bg-light rounded-lg p-2">
                            <div class="date-month text-primary small fw-bold">MAY</div>
                            <div class="date-day fs-4 fw-bold">14</div>
                            <div class="date-time small text-muted">09:30 AM</div>
                          </div>
                          <div>
                            <h6 class="mb-1 fw-bold">Regular Check-up</h6>
                            <span class="badge bg-warning text-white rounded-pill">
                              <i class="bi bi-clock-fill me-1"></i> Pending
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div class="row g-3 mb-3">
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Doctor</div>
                              <div class="fw-semibold">Dr. Emon Sheikh</div>
                              <div class="small text-muted">Ophthalmologist</div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=JW" alt="Patient" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Patient</div>
                              <div class="fw-semibold">James Wilson</div>
                              <div class="small text-muted">+1 (555) 123-4567</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="d-flex gap-2 justify-content-end">
                        <button class="btn btn-sm btn-outline-secondary">
                          <i class="bi bi-pencil"></i> Edit
                        </button>
                        <button class="btn btn-sm btn-outline-danger">
                          <i class="bi bi-x-circle"></i> Cancel
                        </button>
                        <button class="btn btn-sm btn-primary">
                          <i class="bi bi-check-circle"></i> Complete
                        </button>
                      </div>
                    </div>
                  </div>

                  <!-- Appointment Card -->
                  <div class="card border-0 shadow-sm rounded-lg mb-3">
                    <div class="card-body p-3">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                          <div class="date-box text-center me-3 bg-light rounded-lg p-2">
                            <div class="date-month text-primary small fw-bold">MAY</div>
                            <div class="date-day fs-4 fw-bold">14</div>
                            <div class="date-time small text-muted">11:00 AM</div>
                          </div>
                          <div>
                            <h6 class="mb-1 fw-bold">Follow-up Visit</h6>
                            <span class="badge bg-warning text-white rounded-pill">
                              <i class="bi bi-clock-fill me-1"></i> Pending
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div class="row g-3 mb-3">
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Doctor</div>
                              <div class="fw-semibold">Dr. Emon Sheikh</div>
                              <div class="small text-muted">Ophthalmologist</div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=SC" alt="Patient" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Patient</div>
                              <div class="fw-semibold">Sophia Chen</div>
                              <div class="small text-muted">+1 (555) 987-6543</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="d-flex gap-2 justify-content-end">
                        <button class="btn btn-sm btn-outline-secondary">
                          <i class="bi bi-pencil"></i> Edit
                        </button>
                        <button class="btn btn-sm btn-outline-danger">
                          <i class="bi bi-x-circle"></i> Cancel
                        </button>
                        <button class="btn btn-sm btn-primary">
                          <i class="bi bi-check-circle"></i> Complete
                        </button>
                      </div>
                    </div>
                  </div>

                  <!-- Appointment Card -->
                  <div class="card border-0 shadow-sm rounded-lg mb-3">
                    <div class="card-body p-3">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                          <div class="date-box text-center me-3 bg-light rounded-lg p-2">
                            <div class="date-month text-primary small fw-bold">MAY</div>
                            <div class="date-day fs-4 fw-bold">15</div>
                            <div class="date-time small text-muted">10:00 AM</div>
                          </div>
                          <div>
                            <h6 class="mb-1 fw-bold">New Symptoms</h6>
                            <span class="badge bg-warning text-white rounded-pill">
                              <i class="bi bi-clock-fill me-1"></i> Pending
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div class="row g-3 mb-3">
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=Dr.N" alt="Doctor" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Doctor</div>
                              <div class="fw-semibold">Dr. Nadia Rahman</div>
                              <div class="small text-muted">Ophthalmologist</div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=MR" alt="Patient" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Patient</div>
                              <div class="fw-semibold">Michael Rodriguez</div>
                              <div class="small text-muted">+1 (555) 456-7890</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="d-flex gap-2 justify-content-end">
                        <button class="btn btn-sm btn-outline-secondary">
                          <i class="bi bi-pencil"></i> Edit
                        </button>
                        <button class="btn btn-sm btn-outline-danger">
                          <i class="bi bi-x-circle"></i> Cancel
                        </button>
                        <button class="btn btn-sm btn-primary">
                          <i class="bi bi-check-circle"></i> Complete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="tab-pane fade" id="past" role="tabpanel" aria-labelledby="past-tab">
                  <!-- Appointment Card (Completed) -->
                  <div class="card border-0 shadow-sm rounded-lg mb-3">
                    <div class="card-body p-3">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                          <div class="date-box text-center me-3 bg-light rounded-lg p-2">
                            <div class="date-month text-primary small fw-bold">MAY</div>
                            <div class="date-day fs-4 fw-bold">10</div>
                            <div class="date-time small text-muted">09:30 AM</div>
                          </div>
                          <div>
                            <h6 class="mb-1 fw-bold">Regular Check-up</h6>
                            <span class="badge bg-success text-white rounded-pill">
                              <i class="bi bi-check-circle-fill me-1"></i> Completed
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div class="row g-3 mb-3">
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=Dr.E" alt="Doctor" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Doctor</div>
                              <div class="fw-semibold">Dr. Emon Sheikh</div>
                              <div class="small text-muted">Ophthalmologist</div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=RH" alt="Patient" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Patient</div>
                              <div class="fw-semibold">Robert Harris</div>
                              <div class="small text-muted">+1 (555) 234-5678</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="d-flex gap-2 justify-content-end">
                        <button class="btn btn-sm btn-outline-secondary">
                          <i class="bi bi-file-text"></i> View Report
                        </button>
                        <button class="btn btn-sm btn-primary">
                          <i class="bi bi-calendar-plus"></i> New Appointment
                        </button>
                      </div>
                    </div>
                  </div>

                  <!-- Appointment Card (Completed) -->
                  <div class="card border-0 shadow-sm rounded-lg mb-3">
                    <div class="card-body p-3">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                          <div class="date-box text-center me-3 bg-light rounded-lg p-2">
                            <div class="date-month text-primary small fw-bold">MAY</div>
                            <div class="date-day fs-4 fw-bold">8</div>
                            <div class="date-time small text-muted">02:30 PM</div>
                          </div>
                          <div>
                            <h6 class="mb-1 fw-bold">Prescription Renewal</h6>
                            <span class="badge bg-success text-white rounded-pill">
                              <i class="bi bi-check-circle-fill me-1"></i> Completed
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div class="row g-3 mb-3">
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=Dr.R" alt="Doctor" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Doctor</div>
                              <div class="fw-semibold">Dr. Rebecca Johnson</div>
                              <div class="small text-muted">Ophthalmologist</div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=EP" alt="Patient" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Patient</div>
                              <div class="fw-semibold">Emily Parker</div>
                              <div class="small text-muted">+1 (555) 876-5432</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="d-flex gap-2 justify-content-end">
                        <button class="btn btn-sm btn-outline-secondary">
                          <i class="bi bi-file-text"></i> View Report
                        </button>
                        <button class="btn btn-sm btn-primary">
                          <i class="bi bi-calendar-plus"></i> New Appointment
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="tab-pane fade" id="cancelled" role="tabpanel" aria-labelledby="cancelled-tab">
                  <!-- Appointment Card (Cancelled) -->
                  <div class="card border-0 shadow-sm rounded-lg mb-3">
                    <div class="card-body p-3">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex align-items-center">
                          <div class="date-box text-center me-3 bg-light rounded-lg p-2">
                            <div class="date-month text-primary small fw-bold">MAY</div>
                            <div class="date-day fs-4 fw-bold">12</div>
                            <div class="date-time small text-muted">11:30 AM</div>
                          </div>
                          <div>
                            <h6 class="mb-1 fw-bold">Test Results Review</h6>
                            <span class="badge bg-danger text-white rounded-pill">
                              <i class="bi bi-x-circle-fill me-1"></i> Cancelled
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div class="row g-3 mb-3">
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=Dr.N" alt="Doctor" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Doctor</div>
                              <div class="fw-semibold">Dr. Nadia Rahman</div>
                              <div class="small text-muted">Ophthalmologist</div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="d-flex align-items-center">
                            <img src="https://placehold.co/120x120?text=JW" alt="Patient" class="rounded-circle border" width="50" height="50">
                            <div class="ms-3">
                              <div class="text-muted small">Patient</div>
                              <div class="fw-semibold">James Wilson</div>
                              <div class="small text-muted">+1 (555) 123-4567</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="d-flex gap-2 justify-content-end">
                        <button class="btn btn-sm btn-primary">
                          <i class="bi bi-calendar-plus"></i> Reschedule
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="mt-4 text-center">
                <button class="btn btn-outline-primary px-4">Load More</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Appointment Booking Form -->
        <div class="col-lg-6">
          <div class="card border-0 shadow-sm rounded-lg">
            <div class="card-body p-4">
              <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 fw-bold">Book New Appointment</h5>
                <div class="step-indicator d-flex align-items-center">
                  <div class="step-dots d-flex gap-2">
                    <div class="step-dot active" data-step="1"></div>
                    <div class="step-dot" data-step="2"></div>
                    <div class="step-dot" data-step="3"></div>
                  </div>
                  <span class="badge bg-primary ms-2 px-3 py-2">Step 1 of 3</span>
                </div>
              </div>
              
              <?php if($errors->any()): ?>
                <div class="alert alert-danger rounded-lg border-0 shadow-sm">
                  <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              <?php endif; ?>
            
              <form class="appointment-form" method="POST" action="<?php echo e(route('appointment.store')); ?>">
                <?php echo csrf_field(); ?>
                <!-- Step 1: Patient Information -->
                <div class="form-step active" id="step1">
                  <div class="card bg-light border-0 rounded-lg mb-4">
                    <div class="card-body p-3">
                      <h6 class="card-title d-flex align-items-center mb-3">
                        <span class="step-number bg-primary text-white rounded-circle me-2">1</span>
                        Patient Information
                      </h6>
                      
                      <div class="mb-4">
                        <label class="form-label fw-semibold">Patient Type</label>
                        <div class="d-flex gap-4">
                          <div class="form-check custom-radio">
                            <input class="form-check-input" type="radio" name="patientType" id="existingPatient" checked>
                            <label class="form-check-label" for="existingPatient">
                              Existing Patient
                            </label>
                          </div>
                          <div class="form-check custom-radio">
                            <input class="form-check-input" type="radio" name="patientType" id="newPatient">
                            <label class="form-check-label" for="newPatient">
                              New Patient
                            </label>
                          </div>
                        </div>
                      </div>
                      
                      <div class="mb-4">
                        <label for="patientSearch" class="form-label fw-semibold">Search Patient</label>
                        <div class="input-group">
                          <span class="input-group-text bg-white border-end-0">
                            <i class="bi bi-search text-muted"></i>
                          </span>
                          <input type="text" class="form-control border-start-0 ps-0" id="patientSearch" placeholder="Type patient name or ID">
                        </div>
                      </div>
                      
                      <div class="selected-patient mb-3">
                        <div class="card border-0 shadow-sm">
                          <div class="card-body p-3">
                            <div class="d-flex align-items-center">
                              <img src="https://placehold.co/100x100?text=JW" alt="Patient" class="rounded-circle border" width="60" height="60">
                              <div class="ms-3">
                                <h6 class="mb-1 fw-bold">James Wilson</h6>
                                <div class="d-flex flex-wrap gap-3">
                                  <span class="badge bg-light text-dark">ID: PT-20240514-001</span>
                                  <span class="badge bg-light text-dark">Age: 42</span>
                                  <span class="badge bg-light text-dark">Phone: +1 (555) 123-4567</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div class="d-flex justify-content-end">
                    <button type="button" class="btn btn-primary px-4" id="nextToStep2">
                      Continue <i class="bi bi-arrow-right ms-1"></i>
                    </button>
                  </div>
                </div>
                
                <!-- Step 2: Department & Doctor Selection -->
                <div class="form-step" id="step2">
                  <div class="card bg-light border-0 rounded-lg mb-4">
                    <div class="card-body p-3">
                      <h6 class="card-title d-flex align-items-center mb-3">
                        <span class="step-number bg-primary text-white rounded-circle me-2">2</span>
                        Department & Doctor
                      </h6>
                      
                      <div class="mb-4">
                        <label for="departmentSelect" class="form-label fw-semibold">Select Department</label>
                        <select class="form-select" id="departmentSelect">
                          <option selected disabled>Choose department</option>
                          <option>Cardiology</option>
                          <option>Neurology</option>
                          <option>Ophthalmology</option>
                          <option>Dermatology</option>
                          <option>Psychiatry</option>
                          <option>Orthopedics</option>
                        </select>
                      </div>
                      
                      <div class="mb-3">
                        <label class="form-label fw-semibold">Select Doctor</label>
                        
                        <div class="row g-3">
                          <div class="col-md-4">
                            <div class="doctor-card">
                              <input type="radio" name="doctorSelect" id="doctor1" class="doctor-card-input">
                              <label for="doctor1" class="doctor-card-label card h-100 border-0 shadow-sm">
                                <div class="card-body p-3 text-center">
                                  <img src="https://placehold.co/100x100?text=Dr.E" alt="Doctor" class="rounded-circle border mb-3" width="70" height="70">
                                  <h6 class="fw-bold mb-1">Dr. Emon Sheikh</h6>
                                  <p class="text-muted small mb-2">Ophthalmologist</p>
                                  <div class="doctor-rating">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-half text-warning"></i>
                                    <span class="ms-1 small">4.8</span>
                                  </div>
                                </div>
                              </label>
                            </div>
                          </div>
                          
                          <div class="col-md-4">
                            <div class="doctor-card">
                              <input type="radio" name="doctorSelect" id="doctor2" class="doctor-card-input">
                              <label for="doctor2" class="doctor-card-label card h-100 border-0 shadow-sm">
                                <div class="card-body p-3 text-center">
                                  <img src="https://placehold.co/100x100?text=Dr.N" alt="Doctor" class="rounded-circle border mb-3" width="70" height="70">
                                  <h6 class="fw-bold mb-1">Dr. Nadia Rahman</h6>
                                  <p class="text-muted small mb-2">Ophthalmologist</p>
                                  <div class="doctor-rating">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                    <span class="ms-1 small">4.1</span>
                                  </div>
                                </div>
                              </label>
                            </div>
                          </div>
                          
                          <div class="col-md-4">
                            <div class="doctor-card">
                              <input type="radio" name="doctorSelect" id="doctor3" class="doctor-card-input">
                              <label for="doctor3" class="doctor-card-label card h-100 border-0 shadow-sm">
                                <div class="card-body p-3 text-center">
                                  <img src="https://placehold.co/100x100?text=Dr.R" alt="Doctor" class="rounded-circle border mb-3" width="70" height="70">
                                  <h6 class="fw-bold mb-1">Dr. Rebecca Johnson</h6>
                                  <p class="text-muted small mb-2">Ophthalmologist</p>
                                  <div class="doctor-rating">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <span class="ms-1 small">5.0</span>
                                  </div>
                                </div>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div class="d-flex justify-content-between">
                    <button type="button" class="btn btn-outline-secondary px-4" id="backToStep1">
                      <i class="bi bi-arrow-left me-1"></i> Back
                    </button>
                    <button type="button" class="btn btn-primary px-4" id="nextToStep3">
                      Continue <i class="bi bi-arrow-right ms-1"></i>
                    </button>
                  </div>
                </div>
                
                <!-- Step 3: Date & Time Selection -->
                <div class="form-step" id="step3">
                  <div class="card bg-light border-0 rounded-lg mb-4">
                    <div class="card-body p-3">
                      <h6 class="card-title d-flex align-items-center mb-3">
                        <span class="step-number bg-primary text-white rounded-circle me-2">3</span>
                        Appointment Date & Time
                      </h6>
                      
                      <div class="mb-4">
                        <label class="form-label fw-semibold">Select Date</label>
                        <div class="date-picker card border-0 shadow-sm">
                          <div class="card-body p-3">
                            <div class="date-nav d-flex justify-content-between align-items-center mb-3">
                              <button type="button" class="btn btn-sm btn-light rounded-circle">
                                <i class="bi bi-chevron-left"></i>
                              </button>
                              <span class="date-nav-title fw-semibold">May 14 - May 20, 2025</span>
                              <button type="button" class="btn btn-sm btn-light rounded-circle">
                                <i class="bi bi-chevron-right"></i>
                              </button>
                            </div>
                            
                            <div class="date-grid d-flex justify-content-between">
                              <div class="date-item text-center">
                                <div class="date-weekday text-muted mb-2">Tue</div>
                                <div class="date-day-wrapper position-relative">
                                  <input type="radio" name="appointmentDate" id="date14" class="date-input" checked>
                                  <label for="date14" class="date-day-label">14</label>
                                </div>
                              </div>
                              <div class="date-item text-center">
                                <div class="date-weekday text-muted mb-2">Wed</div>
                                <div class="date-day-wrapper position-relative">
                                  <input type="radio" name="appointmentDate" id="date15" class="date-input">
                                  <label for="date15" class="date-day-label">15</label>
                                </div>
                              </div>
                              <div class="date-item text-center">
                                <div class="date-weekday text-muted mb-2">Thu</div>
                                <div class="date-day-wrapper position-relative">
                                  <input type="radio" name="appointmentDate" id="date16" class="date-input">
                                  <label for="date16" class="date-day-label">16</label>
                                </div>
                              </div>
                              <div class="date-item text-center">
                                <div class="date-weekday text-muted mb-2">Fri</div>
                                <div class="date-day-wrapper position-relative">
                                  <input type="radio" name="appointmentDate" id="date17" class="date-input">
                                  <label for="date17" class="date-day-label">17</label>
                                </div>
                              </div>
                              <div class="date-item text-center">
                                <div class="date-weekday text-muted mb-2">Sat</div>
                                <div class="date-day-wrapper position-relative">
                                  <input type="radio" name="appointmentDate" id="date18" class="date-input">
                                  <label for="date18" class="date-day-label">18</label>
                                </div>
                              </div>
                              <div class="date-item text-center">
                                <div class="date-weekday text-muted mb-2">Sun</div>
                                <div class="date-day-wrapper position-relative">
                                  <input type="radio" name="appointmentDate" id="date19" class="date-input">
                                  <label for="date19" class="date-day-label">19</label>
                                </div>
                              </div>
                              <div class="date-item text-center">
                                <div class="date-weekday text-muted mb-2">Mon</div>
                                <div class="date-day-wrapper position-relative">
                                  <input type="radio" name="appointmentDate" id="date20" class="date-input">
                                  <label for="date20" class="date-day-label">20</label>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="mb-4">
                        <label class="form-label fw-semibold">Select Time Slot</label>
                        <div class="row g-3">
                          <div class="col-md-4">
                            <div class="card border-0 shadow-sm h-100">
                              <div class="card-body p-3">
                                <h6 class="card-title text-primary mb-3">Morning</h6>
                                <div class="time-slots">
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time1" class="time-slot-input">
                                    <label for="time1" class="time-slot-label">09:00 AM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time2" class="time-slot-input" checked>
                                    <label for="time2" class="time-slot-label">09:30 AM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time3" class="time-slot-input">
                                    <label for="time3" class="time-slot-label">10:00 AM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time4" class="time-slot-input" disabled>
                                    <label for="time4" class="time-slot-label">10:30 AM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time5" class="time-slot-input">
                                    <label for="time5" class="time-slot-label">11:00 AM</label>
                                  </div>
                                  <div class="time-slot-item">
                                    <input type="radio" name="timeSlot" id="time6" class="time-slot-input">
                                    <label for="time6" class="time-slot-label">11:30 AM</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div class="col-md-4">
                            <div class="card border-0 shadow-sm h-100">
                              <div class="card-body p-3">
                                <h6 class="card-title text-primary mb-3">Afternoon</h6>
                                <div class="time-slots">
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time7" class="time-slot-input" disabled>
                                    <label for="time7" class="time-slot-label">01:00 PM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time8" class="time-slot-input" disabled>
                                    <label for="time8" class="time-slot-label">01:30 PM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time9" class="time-slot-input">
                                    <label for="time9" class="time-slot-label">02:00 PM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time10" class="time-slot-input">
                                    <label for="time10" class="time-slot-label">02:30 PM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time11" class="time-slot-input">
                                    <label for="time11" class="time-slot-label">03:00 PM</label>
                                  </div>
                                  <div class="time-slot-item">
                                    <input type="radio" name="timeSlot" id="time12" class="time-slot-input">
                                    <label for="time12" class="time-slot-label">03:30 PM</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div class="col-md-4">
                            <div class="card border-0 shadow-sm h-100">
                              <div class="card-body p-3">
                                <h6 class="card-title text-primary mb-3">Evening</h6>
                                <div class="time-slots">
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time13" class="time-slot-input">
                                    <label for="time13" class="time-slot-label">04:00 PM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time14" class="time-slot-input">
                                    <label for="time14" class="time-slot-label">04:30 PM</label>
                                  </div>
                                  <div class="time-slot-item mb-2">
                                    <input type="radio" name="timeSlot" id="time15" class="time-slot-input">
                                    <label for="time15" class="time-slot-label">05:00 PM</label>
                                  </div>
                                  <div class="time-slot-item">
                                    <input type="radio" name="timeSlot" id="time16" class="time-slot-input">
                                    <label for="time16" class="time-slot-label">05:30 PM</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div class="mb-3">
                        <label for="appointmentReason" class="form-label fw-semibold">Reason for Appointment</label>
                        <select class="form-select" id="appointmentReason">
                          <option selected disabled>Select reason</option>
                          <option>Regular Check-up</option>
                          <option>Follow-up Visit</option>
                          <option>New Symptoms</option>
                          <option>Prescription Renewal</option>
                          <option>Test Results Review</option>
                          <option>Other</option>
                        </select>
                      </div>
                      
                      <div class="mb-3">
                        <label for="appointmentNotes" class="form-label fw-semibold">Additional Notes</label>
                        <textarea class="form-control" id="appointmentNotes" rows="3" placeholder="Provide any details about your condition or specific needs"></textarea>
                      </div>
                    </div>
                  </div>
                  
                  <div class="d-flex justify-content-between">
                    <button type="button" class="btn btn-outline-secondary px-4" id="backToStep2">
                      <i class="bi bi-arrow-left me-1"></i> Back
                    </button>
                    <button type="submit" class="btn btn-success px-4">
                      <i class="bi bi-calendar-check me-1"></i> Book Appointment
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
          
          <!-- Doctor Schedule Card -->
          <div class="mt-4">
            <div class="card border-0 shadow-sm rounded-lg">
              <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                  <h5 class="mb-0 fw-bold">Doctor's Schedule</h5>
                  <button class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-calendar3 me-1"></i> View Full Calendar
                  </button>
                </div>
                
                <div class="schedule-timeline d-flex gap-3 overflow-auto pb-2">
                  <div class="schedule-day">
                    <div class="card border-0 shadow-sm">
                      <div class="card-body p-3">
                        <div class="schedule-date text-center mb-3">
                          <span class="schedule-weekday d-block text-primary fw-bold">Today</span>
                          <span class="schedule-day-num d-block fs-4 fw-bold">14</span>
                        </div>
                        <div class="schedule-appointments">
                          <div class="schedule-appointment-item card border-0 bg-light mb-2">
                            <div class="card-body p-2">
                              <div class="schedule-time badge bg-primary mb-1">09:30 AM</div>
                              <div class="schedule-info">
                                <h6 class="mb-0 fw-bold">James Wilson</h6>
                                <p class="mb-0 small text-muted">Regular Check-up</p>
                              </div>
                            </div>
                          </div>
                          <div class="schedule-appointment-item card border-0 bg-light">
                            <div class="card-body p-2">
                              <div class="schedule-time badge bg-primary mb-1">11:00 AM</div>
                              <div class="schedule-info">
                                <h6 class="mb-0 fw-bold">Sophia Chen</h6>
                                <p class="mb-0 small text-muted">Follow-up Visit</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div class="schedule-day">
                    <div class="card border-0 shadow-sm">
                      <div class="card-body p-3">
                        <div class="schedule-date text-center mb-3">
                          <span class="schedule-weekday d-block text-muted">Wed</span>
                          <span class="schedule-day-num d-block fs-4 fw-bold">15</span>
                        </div>
                        <div class="schedule-appointments">
                          <div class="schedule-appointment-item card border-0 bg-light mb-2">
                            <div class="card-body p-2">
                              <div class="schedule-time badge bg-primary mb-1">10:00 AM</div>
                              <div class="schedule-info">
                                <h6 class="mb-0 fw-bold">Robert Harris</h6>
                                <p class="mb-0 small text-muted">Prescription Renewal</p>
                              </div>
                            </div>
                          </div>
                          <div class="schedule-appointment-item card border-0 bg-light mb-2">
                            <div class="card-body p-2">
                              <div class="schedule-time badge bg-primary mb-1">02:15 PM</div>
                              <div class="schedule-info">
                                <h6 class="mb-0 fw-bold">Michael Rodriguez</h6>
                                <p class="mb-0 small text-muted">New Symptoms</p>
                              </div>
                            </div>
                          </div>
                          <div class="schedule-appointment-item card border-0 bg-light">
                            <div class="card-body p-2">
                              <div class="schedule-time badge bg-primary mb-1">04:45 PM</div>
                              <div class="schedule-info">
                                <h6 class="mb-0 fw-bold">Emily Parker</h6>
                                <p class="mb-0 small text-muted">Test Results Review</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div class="schedule-day">
                    <div class="card border-0 shadow-sm">
                      <div class="card-body p-3">
                        <div class="schedule-date text-center mb-3">
                          <span class="schedule-weekday d-block text-muted">Thu</span>
                          <span class="schedule-day-num d-block fs-4 fw-bold">16</span>
                        </div>
                        <div class="schedule-appointments">
                          <div class="schedule-appointment-item card border-0 bg-light mb-2">
                            <div class="card-body p-2">
                              <div class="schedule-time badge bg-primary mb-1">09:00 AM</div>
                              <div class="schedule-info">
                                <h6 class="mb-0 fw-bold">David Thompson</h6>
                                <p class="mb-0 small text-muted">Regular Check-up</p>
                              </div>
                            </div>
                          </div>
                          <div class="schedule-appointment-item card border-0 bg-light">
                            <div class="card-body p-2">
                              <div class="schedule-time badge bg-primary mb-1">03:30 PM</div>
                              <div class="schedule-info">
                                <h6 class="mb-0 fw-bold">Sarah Johnson</h6>
                                <p class="mb-0 small text-muted">Follow-up Visit</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<script src="<?php echo e(asset('js/appointment.js')); ?>"></script>

<style>
.card {
  transition: all 0.3s ease;
}

.card:hover {
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05) !important;
}

/* Step Indicator */
.step-indicator {
  display: flex;
  align-items: center;
}

.step-dots {
  display: flex;
  gap: 8px;
}

.step-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: #e2e8f0;
  transition: all 0.3s ease;
}

.step-dot.active {
  background-color: #3b82f6;
}

/* Form Steps */
.form-step {
  display: none;
}

.form-step.active {
  display: block;
  animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Step Number */
.step-number {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  font-size: 12px;
  font-weight: bold;
}

/* Doctor Cards */
.doctor-card {
  position: relative;
}

.doctor-card-input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.doctor-card-label {
  cursor: pointer;
  border: 2px solid transparent !important;
  transition: all 0.3s ease;
}

.doctor-card-input:checked + .doctor-card-label {
  border-color: #3b82f6 !important;
  background-color: rgba(59, 130, 246, 0.05);
}

.doctor-card-input:focus + .doctor-card-label {
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
}

/* Date Selection */
.date-day-wrapper {
  position: relative;
}

.date-input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.date-day-label {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
  font-weight: bold;
  transition: all 0.3s ease;
}

.date-input:checked + .date-day-label {
  background-color: #3b82f6;
  color: white;
}

/* Time Slots */
.time-slot-item {
  position: relative;
}

.time-slot-input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.time-slot-label {
  display: block;
  padding: 8px 12px;
  border-radius: 6px;
  background-color: #f8fafc;
  border: 1px solid #e2e8f0;
  cursor: pointer;
  transition: all 0.3s ease;
}

.time-slot-input:checked + .time-slot-label {
  background-color: #3b82f6;
  color: white;
  border-color: #3b82f6;
}

.time-slot-input:disabled + .time-slot-label {
  background-color: #f1f5f9;
  color: #94a3b8;
  cursor: not-allowed;
  text-decoration: line-through;
}

/* Appointment Cards */
.appointment-status {
  display: inline-flex;
  align-items: center;
  padding: 4px 8px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.appointment-status.pending {
  background-color: #fef3c7;
  color: #d97706;
}

.appointment-status.completed {
  background-color: #d1fae5;
  color: #059669;
}

.appointment-status.cancelled {
  background-color: #fee2e2;
  color: #dc2626;
}

/* Schedule Timeline */
.schedule-timeline {
  display: flex;
  gap: 16px;
  overflow-x: auto;
  padding-bottom: 8px;
}

.schedule-day {
  min-width: 220px;
  flex: 0 0 auto;
}

/* Custom Radio Buttons */
.custom-radio .form-check-input {
  width: 18px;
  height: 18px;
  margin-top: 2px;
}

.custom-radio .form-check-input:checked {
  background-color: #3b82f6;
  border-color: #3b82f6;
}

.custom-radio .form-check-label {
  padding-left: 4px;
}

/* Stat Cards */
.stat-card {
  border-radius: 10px;
  transition: all 0.3s ease;
}

.stat-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
}

.stat-card-value {
  font-size: 24px;
  font-weight: bold;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
  .date-grid {
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
  }
  
  .time-slot-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .doctor-patient-info {
    flex-direction: column;
  }
}

/* Animations */
@keyframes pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
}

.btn-success:hover {
  animation: pulse 1s infinite;
}
</style>
<?php echo $__env->make('layout.dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laravel\hosp-mgmt\resources\views/dashboard/appointment.blade.php ENDPATH**/ ?>