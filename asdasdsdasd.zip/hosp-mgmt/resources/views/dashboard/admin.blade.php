hosp-mgmt
├── resources
│   └── views
│       └── dashboard
│           ├── admin.blade.php
│           ├── doctor.blade.php
│           └── patient.blade.php
└── public
    └── css
        └── dashboard.css