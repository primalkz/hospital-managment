<!-- cancel Appointment Modal -->
<div class="modal fade" id="cancelAppointmentModal" tabindex="-1" aria-labelledby="cancelAppointmentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="cancelAppointmentModalLabel">Cancel Appointment</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>      <form id="cancelAppointmentForm" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
              <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>
          <input type="hidden" id="cancelAppointmentId" name="appointment_id">
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">No</button>
            <button type="submit" class="btn btn-danger">Yes, I want to cancel</button>
          </div>
      </form>
    </div>
  </div>
</div><?php /**PATH D:\Development\laravel\hosp-mgmt\resources\views/dashboard/modals/appointment-cancel.blade.php ENDPATH**/ ?>